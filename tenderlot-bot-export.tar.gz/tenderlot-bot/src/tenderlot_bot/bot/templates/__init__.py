"""Ukrainian message templates."""
