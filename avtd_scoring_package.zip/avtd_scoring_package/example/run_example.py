"""
Example: how to call calculate_score() with vision output.

In production, vision_output comes from Claude Vision API.
For testing, load from the example JSON file.
"""
import json
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from avtd_scoring import calculate_score

# Load example vision output
with open(os.path.join(os.path.dirname(__file__),
          'vision_output_example.json')) as f:
    vision_output = json.load(f)

# Run scoring
result = calculate_score(vision_output)

# Print results
print(f"Score:  {result['score']}/100")
print(f"Passed: {result['passed']}")
print(f"Phase:  {result['phase']}")
print()
print("Shelf share:")
for cat, data in result['shelf_share'].items():
    if isinstance(data, dict) and 'percent' in data:
        print(f"  {cat}: {data['percent']}%")
print()
if result['errors']:
    print(f"Errors ({len(result['errors'])}):")
    for e in result['errors']:
        print(f"  [{e['code']}] {e['description']}")
else:
    print("No errors")
print()
if result['info']:
    print("Info:")
    for i in result['info']:
        print(f"  {i}")
