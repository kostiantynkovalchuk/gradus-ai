# AVTD Photo Report — Scoring Module

Deterministic scoring engine for shelf compliance reports.

## What it does

Takes structured JSON output from Claude Vision API and returns
a compliance score, pass/fail result, and list of violations.

**No AI involved in scoring** — all rules are deterministic Python.
Claude Vision provides the facts (facing counts, brand detection).
This module applies AVTD business rules to those facts.

## Requirements

- Python 3.8+
- No external dependencies (stdlib only)

## Installation

Copy the `avtd_scoring/` folder into your project.

## Usage

```python
from avtd_scoring import calculate_score

# vision_output is the dict returned by Claude Vision API
result = calculate_score(vision_output)

print(result['score'])   # int 0-100
print(result['passed'])  # bool
print(result['errors'])  # list of violation dicts
```

## Input format

See `example/vision_output_example.json` for the complete
input structure. Key fields:

| Field | Type | Description |
|-------|------|-------------|
| vodka.greenday_facings | int | GreenDay facing count |
| vodka.ukrainka_facings | int | Ukrainka facing count |
| vodka.helsinki_facings | int | Helsinki facing count |
| vodka.total_vodka_facings | int | All vodka facings |
| cognac.adjari_facings | int | ADJARI facing count |
| cognac.total_cognac_facings | int | All cognac facings |
| wine.villa_ua_facings | int | Villa UA facing count |
| wine.total_wine_facings | int | All wine facings |
| sparkling.villa_ua_sparkling_facings | int | Villa UA sparkling |
| sparkling.total_sparkling_facings | int | All sparkling |
| has_general_overview | bool | Full shelf overview present |
| pos_materials.avtd_shelf_strip_present | bool | AVTD POS visible |
| premium_shelf.top_shelf_visible | bool | Premium shelf in frame |
| premium_shelf.gd_evolution_present | bool | GD Evolution on shelf |

## Output format

| Field | Type | Description |
|-------|------|-------------|
| score | int | 0–100 compliance score |
| passed | bool | true if score≥70, errors≤2, no auto_fail |
| errors | list | Violations with code, description, severity |
| shelf_share | dict | AVTD % per category |
| brands_found | dict | Brand-level facing counts |
| info | list | Informational messages (no score impact) |
| warnings | list | Non-critical warnings |

## Scoring thresholds (Phase 2)

| Category | Minimum AVTD share |
|----------|--------------------|
| Vodka | 25% (auto-fail below this) |
| Cognac | 33% |
| Wine | 40% |
| Sparkling | 20% |

Pass conditions:
- score ≥ 70
- errors ≤ 2
- no auto_fail errors

## Integration notes

This module is designed to be called after your image
analysis step returns facing counts per brand. The input
JSON schema matches the output of the AVTD Claude Vision
prompt (available separately from Gradus AI).

For questions: contact Gradus AI / AVTD Digital team
